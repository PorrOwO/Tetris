# Tetris
progetto università

Allìinterno della directory src è presente il codice sorgente

Compilazione:
Per compilare il progetto basta andare nella directory src e eseguire il comando "make" sul terminale
oppure scrivere il comando "g++ *.cpp -lncurses -o "nome_eseguibile" "

Esecuzione:
per eseguire il file create precedentemente con la compilazione bisogna:
eseguire il comando "./nome_eseguibile"

